module.exports = async (client, player) => {

	client.logger.log(`Player has been created in ${player.guild}`, "log");

}